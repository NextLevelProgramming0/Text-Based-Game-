##Darius Quick

def instructions(): ##creating a function with instructions for the user to understand and play the game
    print('A dictionary for the simplified Are you smarter than a first grader game') ##game description for the user
    print('Move commands: go South, go North, go East, go West, and exit') ##game commands for the user
    print('Add item to bookbag: get Item', 'Check Items in Bookbag: check Bookbag')

instructions() ##using the function to output game instructions and commands for the user

##Below is a dictionary for each room in the school and the results of a direction command
rooms = {
'School Grounds' : {'go East' : 'School Entrance'},
'School Entrance' : {'go East' : 'Math Lounge', 'go South' : 'Writing Classroom'},
'Math Lounge': {'go West' : 'School Entrance', 'go East' : 'Reading Hall', 'go South' : 'Science Lab'},
'Reading Hall' : {'West' : 'Math Lounge', 'South' : 'Social Café'},
'Writing Classroom' : {'go North' : 'School Entrance', 'go East' : 'Science Lab', 'go South' : 'Artistic Room'},
'Science Lab' : {'go West' : 'Writing Classroom', 'go North' : 'Math Lounge', 'go East' : 'Social Café'},
'Social Café' : {'go West' : 'Science Lab', 'go North' : 'Reading Hall'},
'Artistic Room' : {'go North' : 'Writing Classroom', 'go East' : 'Principal’s Office'},
'Principals Office' : {'go West' : 'Artistic Room'}
}

curr_location = list(rooms.keys())[0] ##This is location that the user starts the game in

##Below is a dictionary for all the item locations the player has to go to collect
item_locations = {'Math Lounge' : 'Math Scroll', 'Reading Hall' : 'Reading Scroll',
 'Writing Classroom' : 'Writing Scroll', 'Science Lab' : 'Science Scroll',
  'Social Cafe' : 'Social Studies Scroll', 'Artistic Room' : 'Visual Arts Scroll'
}

bookbag = [] ## This is the empty list that the items the player collects will go into

## Below is a list of what a the bookbag will look like upon game completion
full_bookbag = ['Math Scroll', 'Reading Scroll', 'Science Scroll',
 'Social Studies Scroll', 'Visual Arts Scroll', 'Writing Scroll'
 ]

curr_item = 0

while True:
    if user_action == 'exit':
        print('Thank you for playing the game.  Hope you Enjoyed it!') ##this is what happens if the user inputs the exit command
        break ##This ends the game and loop
    elif sort(bookbag) == full_bookbag and curr_location == 'Principals Office': ##Loop branch conditions allowing the player to win the game
        print('Principal: Congratulations student! You have graduated the first grade!')
        break
    elif sort(bookbag) != full_bookbag and curr_location != 'Principals Office': ##Loop branch if the player hasn't met the conditions to win the game
        print("You are in the", curr_location) ##this will output for the user what room they are in
        print("Where would you like to go or what would you like to do?") ##this will output instructions for the user
        user_action = str(input())  ##this asks the user to input a game command
        if user_action in rooms[curr_location].keys():  ##connects user action to the dictionary
	    curr_location = rooms[curr_location][user_action] ##this is what happens if the user inputs a valid direction command
	    elif user_action == 'get Item' and curr_location in item_locations: ##This loop branch allows a player to collect items
	    curr_item = item_locations[curr_location]
	        if curr_item in bookbag:  ## This loop branch executes if the player already has an item in their bookbag
	        print('You already have that item')
	        else:  ##this loop branch executes if the player does not have the item in their bookbag
	        print('You have studies the', curr_item + '!')
	        bookbag.append(curr_item)
    else:
        print('Invalid Command') ##This branch executes if a user inputs anything other than a valid command

